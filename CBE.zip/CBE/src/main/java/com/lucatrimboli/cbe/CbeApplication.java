package com.lucatrimboli.cbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {
		"com.lucatrimboli.cbe.*"
})
public class CbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbeApplication.class, args);
	}

}

