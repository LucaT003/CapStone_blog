package com.lucatrimboli.cbe.models;

public enum RoleType {
	
    ROLE_USER,
    ROLE_ADMIN;
	
}
